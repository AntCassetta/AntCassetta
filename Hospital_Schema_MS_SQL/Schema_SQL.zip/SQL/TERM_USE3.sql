--add to first doc's waitlist
EXEC add_waitlist 1, 300400500, 111124;

--add to first doc's waitlist
EXEC add_waitlist 1, 300400501, 111115;

SELECT * FROM waitlist;