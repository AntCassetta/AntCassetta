The application included is a proof of concept of Refrigerator Raider a refrigerator inventory management system.

Written by Anthony “Ant” Cassetta.

Compilation instructions:

I recommend you load the project into eclipse.

If you’d like to compile it manually via the terminal.

Compile the framework packages:
	dataStructures
	inventory
	io

Then compile the business logic
	raiderInventories
	userProfiles
	dataIO
	RefrigeratorRaider
	utilities