package RefrigeratorRaider;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Vector;
import java.util.regex.Pattern;

import dataIO.ProxyReadTxtFile;
import io.ReadFile;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import raiderInventories.InventoryManager;
import userProfiles.RaiderUser;


/**LogIn is a state used in the control of the Refrigerator Raider. LogIn is the initial state which facilitates user LogIn 
 * @author anthonycassetta
 */
public class LogIn implements State{
	
	private Vector<String> candidate;
	private Vector<String> roster;
	private ReadFile readUserFile = new ProxyReadTxtFile();
	InventoryManager Manager = InventoryManager.getInstance();
	
	@FXML
	private Button buttonLogin;
	@FXML
	private TextField txtUserName;
	@FXML
	private TextField txtUserID;
	@FXML
	private TextField txtUserType;
	@FXML
	private Label lblstatus;
	
	Context context;
	State state;
	RaiderUser activeUser;
	
	/*
	public LogIn(Context givenContext) {
		
		this.context = givenContext;
		activeUser = context.getUser();
		
	}//end constructor*/
	
	
	/**startLogIn prompts the end user for in their caseSentsative user name, user ID and user Type. 
	 * Then checks this information against the userList.
	 * If a match is found the appropriate values are set within the User object for the remainder of runtime.
	 * @param givenUser the the singleton User object to be configured by the log in process.
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public void startLogIn(ActionEvent event) throws FileNotFoundException, IOException {
		
		context = new Context();
		context.setState(this);
		activeUser = context.getUser();
		
		String inputName = txtUserName.getText();
		
		int inputInt = 999;
		try {
			inputInt = Integer.parseInt(txtUserID.getText());
		} catch (NumberFormatException e) {
			System.out.println(e + "\nNot a valid UserId");
		}//end try catch
		
		
		String inputType = txtUserType.getText();
		
		candidate = readUserFile.readUserFile(inputName, inputInt, inputType.toUpperCase());
		
		if (candidate.size() < 3 || candidate.size() > 3) {
			System.out.println("We did not find a registered user for :" + inputName +" " + inputInt);
			lblstatus.setText("Invalid Login");
		
		} else {
			
		activeUser.setUserName(candidate.get(0));
		activeUser.setUserID(Integer.parseInt(candidate.get(1)));
		activeUser.setUserType(candidate.get(2));
		
		loadRoster(activeUser);
		
		if (activeUser.getUserName().equals(inputName)) {
			lblstatus.setText("Success!");
			
			try {
				Stage primaryStage = new Stage();
				Parent root = FXMLLoader.load(getClass().getResource("/RefrigeratorRaider/menu.fxml"));
				Scene scene = new Scene(root,400,600);
				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				primaryStage.setScene(scene);
				primaryStage.show();
			
			} catch(Exception e) {
				
				e.printStackTrace();
			
			}//end try catch
			
		} else {
			
		}//end inner if else
		
		}//end if else
		
	}//end startLogIn

	
	@Override
	/**This method corresponds with the Context object to facilitate the state pattern*/
	public void doAction(Context givenContext) throws FileNotFoundException, IOException {
		
		//LoginGUI.main(null);
		
	}//end doAction
	
	
	/**loadRoster takes the singleton User, loads their roster information and creates instances of their rosters, if any.
	 * @param givenUser
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public void loadRoster(RaiderUser givenUser) throws FileNotFoundException, IOException {
		String[] rosterLine;
		roster = readUserFile.readRosterFile(givenUser.getUserName(), givenUser.getUserID());
		for (String I : roster) {
		
			rosterLine = I.split(Pattern.quote(","));
			//System.out.println(rosterLine[0]+ Long.parseLong(rosterLine[1].trim())+ rosterLine[2].trim());
			Manager.addInventory(rosterLine[0], Long.parseLong(rosterLine[1].trim()), rosterLine[2].trim());

		}//end for
	}//end loadRoster
	
	
	/** Returns a string representation of the object. This method is used to confirm the current state of Context.*/
	 public String toString() { return "LogIn"; }//end toString

}// end LogIn