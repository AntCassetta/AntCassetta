package RefrigeratorRaider;

import java.io.FileNotFoundException;
import java.io.IOException;

/**Basic interface for implementing various states of Refrigerator Raider
 * @author anthonycassetta
 */
public interface State {
	   public void doAction(Context context) throws FileNotFoundException, IOException;
	}//end State