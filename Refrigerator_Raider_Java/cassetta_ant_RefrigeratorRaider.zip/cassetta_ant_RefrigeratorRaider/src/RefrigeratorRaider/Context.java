package RefrigeratorRaider;

/**Context class used to hold current state and active user session.
 * @author anthonycassetta
 */
import userProfiles.RaiderUser;

public class Context {
	
	   private RaiderUser activeUser;
	   
	   private State state;

	   public Context(){
	      state = null;
	      activeUser = RaiderUser.getInstane(); 
	      System.out.println("Context active user" + activeUser);
	   }
	   
	   /**Sets the current state of the context*/
	   public void setState(State state){
	      this.state = state;		
	   }

	   /**returns the current state object*/
	   public State getState(){
	      return state;
	   }
	   
	   /**@return The active user for the session*/
	   public RaiderUser getUser(){return activeUser;}
	
}
