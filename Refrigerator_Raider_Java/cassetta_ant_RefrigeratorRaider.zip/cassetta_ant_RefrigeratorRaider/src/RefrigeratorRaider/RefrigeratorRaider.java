package RefrigeratorRaider;

import java.io.FileNotFoundException;
import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


/**The main class of Refrigerator Raider. upon run the user is prompted to log in, 
 * upon successful log in inventory data is loaded.
 * @author anthonycassetta
 */
public class RefrigeratorRaider extends Application {
	
	//private Scanner scan;
	private Context context;
	private State logIn;
	//private State mainMenu;
	
	/*
	RefrigeratorRaider() {
		//scanner object
		scan = DataScanner.getDataScanner();
		
		//context object
		context = new Context();
		
		//state objects
		logIn = new LogIn();
		mainMenu = new MainMenu();
	}//end constructor
	*/
	
	/**This method is intended for testing purposes only
	 * @return String representation of current state*/
	public String getContextString() { return context.getState().toString(); }
	
	
	/**Constructor made only for testing purposes do not use in production
	 * @param in an InputStream of test data
	 *//*
	RefrigeratorRaider(InputStream in) {
		System.setIn(in);
		scan = new Scanner(System.in);
		
		//context object
		context = new Context();
		
		//state objects
		logIn = new LogIn();
		mainMenu = new MainMenu();
	}//end RefrigeratorRaider
	*/
	
	/**Begins the application session*/
	public void start(Stage primaryStage) {
		
		context = new Context();
		logIn = new LogIn();
		
		//set initial state
		context.setState(logIn);
		
		try {
			runLogin(primaryStage);
		
		} catch(Exception e) {
			e.printStackTrace();
		}//end try catch
		
	}//end start
	
	
	public void runLogin(Stage primaryStage) {
		
		try {
			
			Parent root = FXMLLoader.load(getClass().getResource("/RefrigeratorRaider/Login.fxml"));
			Scene scene = new Scene(root,400,600);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		
		} catch(Exception e) {
			e.printStackTrace();
		}//end try catch
		
	}//end runLogin
	
	
	public void runMenu(Stage primaryStage) {
		
		try {
			
			Parent root = FXMLLoader.load(getClass().getResource("/RefrigeratorRaider/menu.fxml"));
			Scene scene = new Scene(root,400,600);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		
		} catch(Exception e) {
			
			e.printStackTrace();
		
		}//end try catch
		
	}//end runMenu

	
	public static void main(String[] args) throws FileNotFoundException, IOException {
		
		launch(args);

	}//end main


}//end RefrigeratorRaider
