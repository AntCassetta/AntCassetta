package raiderInventories;


/**Produce objects are Item subclass objects represent real world items to be tracked within inventories. 
 * @author anthonycassetta
 */
public class ItemProduce extends RaiderItem{

	public ItemProduce(String givenItemName, int givenItemQuantity, String givenItemType) {
		super(givenItemName, givenItemQuantity, givenItemType);
	}

}//end ProduceItem
