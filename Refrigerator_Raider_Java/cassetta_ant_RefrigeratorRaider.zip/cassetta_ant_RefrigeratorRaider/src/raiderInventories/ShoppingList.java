package raiderInventories;

import inventory.InventoryControl;

/**A concrete implementation of RaiderInventory.
 * Shopping List is an inventory intended to represent a shopping list of items needed.
 * comparable to a groceries list one might take to the grocers.
 * @author anthonycassetta
 */
public class ShoppingList extends RaiderInventory{

	public ShoppingList(InventoryControl newInventoryControl, String nickName, long givenInventoryID) {
		super(newInventoryControl, nickName, givenInventoryID);
		
		System.out.println("Shopping list " + this.getInventoryID() +  " \""+this.getInventoryName() + "\" has been created.");
	}
	
	public String toString() {
		return "ShoppingList";
	};

}//end ShoppingList
