package raiderInventories;

/**Meat objects are Item subclass objects represent real world items to be tracked within inventories. 
 * @author anthonycassetta
 */
public class ItemMeat extends RaiderItem {

	public ItemMeat(String givenItemName, int givenItemQuantity, String givenItemType) {
		super(givenItemName, givenItemQuantity, givenItemType);
	}//end constructor

}
