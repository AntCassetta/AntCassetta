package raiderInventories;

import inventory.InventoryControl;


/**A concrete implementation of RaiderInventory.
 * Refrigerator is an inventory intended to represent the contents of a refrigerator and/or pantry.
 * @author anthonycassetta
 */
public class Refrigerator extends RaiderInventory{

	public Refrigerator(InventoryControl newInventoryControl,
						String nickName, long givenInventoryID) {
		super(newInventoryControl, nickName, givenInventoryID);
		
		System.out.println("Refrigerator " + this.getInventoryID() + " \""+this.getInventoryName() + "\" has been created.");
	}
	
	@Override
	public String toString() {
		return "Refrigerator";
	};
	
}//end refrigerator
