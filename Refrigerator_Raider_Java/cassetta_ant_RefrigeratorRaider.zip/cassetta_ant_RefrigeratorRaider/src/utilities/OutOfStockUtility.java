package utilities;

/**NOT YET IMPLEMENTED
 * OutOfStockUtility will search a given inventory for items of quantity = 0 and lists them for the user.
 * @author anthonycassetta
 */
public class OutOfStockUtility implements StockUtility {
	
	@Override
	public void checkStock(){
		System.out.println("one day, I will check for out of stock items and report back...");
	}
}//end OutOfStockUtility
