package utilities;

/**NOT YET IMPLEMENTED
 * Expiration utility will search a given inventory for expired items or items expiring in two days
 * and lists them for the user.
 * @author anthonycassetta
 */
class ExperationUtility implements StockUtility{
	
	@Override
	public void checkStock() {
		System.out.println("one day, I will check a given inventory for expired items and report back...");
	}//end checkStock

}//end ExperationUtility
