package utilities;
import java.util.Scanner;

/**Singleton Scanner object for accepting user input throughout the session*/
public class DataScanner {
	private static Scanner dataScanner = new Scanner(System.in);  // Reading from System.in
	
	private DataScanner(){}
	
	/**@return a Scanner object scanning system.in
	 */
	public static Scanner getDataScanner(){ return dataScanner; }

}//end DataScanner
