package utilities;

interface StockUtility {
	
	public void checkStock();

}//end StockUtility
