package io;

/**Interface for writing text files containing inventory data.
 * @author anthonycassetta
 */
public interface WriteFile {
	
	public void writeToFile(String givenInvName, int givenInvID, String givenItem, int givenQty);

}